using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Web;
using System.Collections.Generic;

namespace AWWW_lab1_gr5.Controllers
{
    public class HomeController : Controller{
        public IActionResult Index(){
            ViewBag.Title = "Home";
            return View();
        }
    }
}